#ifndef GD_COMPAT_H
#define GD_COMPAT_H 1

/* from gd_compat.c of libgd/gd_security.c */
int overflow2(int a, int b);

#endif /* GD_COMPAT_H */
